/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Farhan
 */
public class vForgetTest {
    
    public vForgetTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getTfEmail method, of class vForget.
     */
    @Test
    public void testGetTfEmail() {
        System.out.println("getTfEmail");
        vForget instance = new vForget();
        String expResult = "";
        String result = instance.getTfEmail();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPfNew_Pw method, of class vForget.
     */
    @Test
    public void testGetPfNew_Pw() {
        System.out.println("getPfNew_Pw");
        vForget instance = new vForget();
        String expResult = "";
        String result = instance.getPfNew_Pw();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPfConfirm_Pw method, of class vForget.
     */
    @Test
    public void testGetPfConfirm_Pw() {
        System.out.println("getPfConfirm_Pw");
        vForget instance = new vForget();
        String expResult = "";
        String result = instance.getPfConfirm_Pw();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of showMessage method, of class vForget.
     */
    @Test
    public void testShowMessage() {
        System.out.println("showMessage");
        String message = "";
        String title = "";
        int type = 0;
        vForget instance = new vForget();
        instance.showMessage(message, title, type);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testMain(){
        System.out.println("main");
        String[] args = null;
        controller.main(args);
    }
    
}
