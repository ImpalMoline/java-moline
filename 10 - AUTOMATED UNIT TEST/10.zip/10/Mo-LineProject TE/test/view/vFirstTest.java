/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Farhan
 */
public class vFirstTest {
    
    public vFirstTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getTfEmail method, of class vFirst.
     */
    @Test
    public void testGetTfEmail() {
        System.out.println("getTfEmail");
        vFirst instance = new vFirst();
        String expResult = "";
        String result = instance.getTfEmail();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPfPassword method, of class vFirst.
     */
    @Test
    public void testGetPfPassword() {
        System.out.println("getPfPassword");
        vFirst instance = new vFirst();
        String expResult = "";
        String result = instance.getPfPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of showMessage method, of class vFirst.
     */
    @Test
    public void testShowMessage() {
        System.out.println("showMessage");
        String message = "";
        String title = "";
        int type = 0;
        vFirst instance = new vFirst();
        instance.showMessage(message, title, type);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testMain(){
        System.out.println("main");
        String[] args = null;
        controller.main(args);
    }
}
